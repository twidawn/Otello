package client;

import javax.swing.JPanel;

public class DcieGame extends JPanel{

}
