package othello;
import javax.swing.*;
import java.awt.*;
public class MainClass{
	/*
	public static final int N = 8;
	public static final int SIZE = 64;
	public static int x = -1;
	public static int y = -1;
	public GameControl gc;
	
	
	public MainClass(){
		gc = new GameControl();
		gc.gameStatus();
	}

	
	public static void main(String[] args) {
		MainClass mc = new MainClass();		
	}
	*/
}
